This directory contains python-3 scripts to write the EAM-X model to
LAMMPS potential files (eam/alloy format), along with a simple test
calculation using LAMMPS.  (See also BriefDescription.txt)
***CONTENTS REVISED May 2023***

See two seminal papers on EAM-X by Daw & Chandross in Acta Mat (2023)
for details. If you use these codes, please reference our two papers
in any resulting publications, but note also that these codes are provided
for research purposes and we cannot be responsible for errors. 

MakeSpreadBinary.py defines the parameters for a "spread
binary". This reads in the parameters for Averagium (baseparams.set)
and "deltas" defining the differences in parameters (deltas.set) for
the two types. It then calls Make_LAMMPS_eamalloy_v2.py to write out
the LAMMPS potential file (called by default here "AB.EAMX.eamalloy").
That script imports model_v2.py which defines the EAMX model.

The file "in.example" is a LAMMPS input file that does a simple LAMMPS
run to evaluate the energy/atom and lattice constant for each type in
the binary.

python MakeSpreadBinary.py
lmps < in.example

compare your results to out.example

...M.S. Daw & M.E. Chandross 4 Jan 2023
***REVISED May 2023***








